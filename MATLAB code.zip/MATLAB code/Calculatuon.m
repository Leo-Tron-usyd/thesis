
M=0.6;%0.6kg
m=0.25;%0.25kg
L=0.25;%0.25m
I=0.0208;%0.0208kgm^2
b=0.15;%0.15N/m/s
g=9.81;%m/s^2



C1=(I+m*L^2)*(M+m)/(m*L);
C2=(M+m)*g;
C3=m*L;
C4=(M+m);
C5=m*L*(m*L/(m*L^2+I));
C6=m*L*((m*L*g)/(m*L^2+I));
%create the matrix
A = [0,0,1,0;
     0,0,0,1;
    (C2)/(C1-C3),0,0,-(b)/(C1-C3);
     (C6/(C4-C5)),0,0,-(b/(C4-C5))];
B = [0; 0;1/(C1-C3); 1/(C4-C5)];
D = [0;0;0;0];
C = [0 1 0 0];
C_sim = eye(4); 

% create state space model  for transfer function 
sys_ss = ss(A,B,C_sim,D);

sys_tf = tf(sys_ss);


W=ctrb(A,B);
syms s;
I_det=eye(4);
determinant = det(s*I_det-A);

% Canonical form
a1=(4371)/21644;
a2=-(2711004312167119)/140737488355328;
a3=-(20709521411486513673)/6092244395925438464;

At=[-a1,-a2,-a3,0;1,0,0,0;0,1,0,0;0,0,1,0];
Bt=[1;0;0;0];
% Reachability/Controllability matrix for canonical form
Wt = ctrb(At,Bt);

% Desirted CP
Mp = 0.01;z=0.826;ts=3; w=3.92/(z*ts);N=5;

CE = s^2 + 2*z*w*s+w^2;
val = solve(CE,s);
realPole = real(val(1));
%solve for parameters
DCP = collect(CE*(s-realPole*10)*(s-realPole*9));
p1=(686)/25;
p2=(480915008)/2175625;
p3=(136194016672)/293709375;
p4= 60236288/156645;
% Coefficient matching
Kt=[p1,p2,p3,p4]+At(1,:);



T=Wt/W;
% Controller gains u = -Kx +kr
K=Kt*T;%state gain

%LQR control
R = 0.01;
Q = diag([10,1,1,1]);
[K1,S1,P1] = lqr(A,B,Q,R);
Ac=A-B*K1;
sys1 = ss(A-B*K1,B,C_sim,[0;0;0;0]);



% observer parameters design
Wo=obsv(At',C);
testing=C*At';
syms l1 l2 l3 l4;
Mo=A-[l1;l2;l3;l4]*C;
CPo=collect(det(s*I_det-Mo));
DCPo=collect((s+11)*(s+10.5)*(s+9.5)*(s+8.5));

coeffs_CPo = coeffs(CPo, s, 'All');
coeffs_DCPo = coeffs(DCPo, s, 'All');

eqns = coeffs_CPo == coeffs_DCPo;
sol = solve(eqns, [l1 l2 l3 l4]);

L_obs= double([sol.l1; sol.l2; sol.l3; sol.l4]);





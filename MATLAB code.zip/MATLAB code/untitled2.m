
M=0.6;%0.6kg
m=0.25;%0.25kg
l=0.25;%0.25m
I=0.0208;%0.0208kgm^2
b=0.15;%0.15N/m/s
g=9.81;%m/s^2


p = I*(M+m)+M*m*l^2; %denominator for the A and B matrices

A = [0      1              0           0;
     0 -(I+m*l^2)*b/p  (m^2*g*l^2)/p   0;
     0      0              0           1;
     0 -(m*l*b)/p       m*g*l*(M+m)/p  0];
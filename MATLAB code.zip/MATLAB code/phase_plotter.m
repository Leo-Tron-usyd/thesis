% 定义频率范围
omega = logspace(-1, 3, 1000); % 从0.1到1000的频率范围，可以根据需要调整

% 计算各个部分的相位（弧度）
phi_2_31 = 0; % 常数2.31的相位为0
phi_jomega = pi/2 * ones(size(omega)); % jω的相位为π/2
phi_jomega_plus_0_1764 = atan2(omega, 0.1764); % jω + 0.1764的相位
phi_jomega_minus_4_3764 = atan2(omega, -4.3764); % jω - 4.3764的相位
phi_jomega_plus_4_4019 = atan2(omega, 4.4019); % jω + 4.4019的相位

% 计算总相位（弧度）
phi_G_s = phi_2_31 + phi_jomega - phi_jomega_plus_0_1764 - phi_jomega_minus_4_3764 - phi_jomega_plus_4_4019;

% 将相位从弧度转换为角度
phi_G_s_deg = phi_G_s * (180 / pi);

% 定义传递函数G(s)
s = tf('s');
G = 2.31 * s / ((s + 0.1764) * (s - 4.3764) * (s + 4.4019));

% 绘制幅频和相频图
figure;
bode(G);
grid on;

% 如果要绘制自定义相位图
figure;
subplot(2,1,1);
plot(omega, 20*log10(abs(G(1j*omega)))); % 绘制幅度（dB）
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');
grid on;

subplot(2,1,2);
plot(omega, phi_G_s_deg); % 绘制相位（度）
xlabel('Frequency (rad/s)');
ylabel('Phase (deg)');
grid on;

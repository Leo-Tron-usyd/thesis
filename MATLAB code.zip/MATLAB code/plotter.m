
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR.signals(2).values,'b');
% hold on;
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR.signals(4).values,'Color', [0, 0, 0.4]);
% hold on;
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_PP.signals(2).values,"r");
% hold on;
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_PP.signals(4).values,'Color', [0.4, 0,0 ]);
% hold on 
plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR.signals(2).values);
hold on
plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR2.signals(2).values);
hold on 
plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR3.signals(2).values);
hold on
plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR4.signals(2).values);
hold on 

title("system output");
xlabel("Time(s)");
ylabel("");
legend("Q=diag([10,1,1,1]) R=0.01","Q=diag([10,10,1,1]) R=1","Q=diag([100,10,1,1]) R=10","Q=diag([10,1,1,1]) R=1")







% hold on
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR.signals(3).values,'b');
% hold on
% plot(out.ScopeData_observer_PP.time,out.ScopeData_observer_LQR.signals(4).values,'Color', [0, 0, 0.4]);
% title("LQR control system output");
% xlabel("Time(s)");
% ylabel("");
% ylim([-12 12])
% legend("reference position","pendulum position Pp","pendulum angle Pp","pendulum position LQR","pendulum angle LQR");
% legend("reference position","pendulum position LQR","pendulum angle LQR");